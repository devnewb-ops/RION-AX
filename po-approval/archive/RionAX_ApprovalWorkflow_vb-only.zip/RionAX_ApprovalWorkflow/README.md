# RionAX Approval Workflow — v6.3

Vendor bill approval driven by a Department × Approval Level matrix.

## What changed in v6.3

| Area | v6.3 behaviour |
|---|---|
| Automatic C-Suite approval | A universal-flagged level (C-Suite) is no longer a departmental band. Bills band against the remaining levels only; when the bill total reaches the universal level, its approval is appended as an ADDITIONAL final step (Department Executive -> C-Suite -> Approved). Approvers for that step come from the (C-Suite, department) matrix cell, then the level's gate fields, then the fallback. Marking a department No Approval Needed at the C-Suite band suppresses the step. |
| Bill-selected Secondary Approver | New editable `custbody_rax_bill_secondary` field on the bill (Approval subtab). Matrix cells ticked "Use bill's Secondary Approver" route to whoever the preparer picked: alone, that person IS the approver; alongside a named primary, they join as co-approver. The selection is part of the approval fingerprint, so changing it resets approvals. A Required cell relying on the flag with an empty bill field routes to the fallback and logs. |
| Direct C-Suite approval | Unchanged from v6.2: universal approvers may decide any bill at any amount in one action, which settles the whole chain. Self-approval policy still applies. |

## What changed in v6.2

| Previous behaviour | v6.2 behaviour |
|---|---|
| Line departments subtotalled per department; multi-step chain per department | The **header department** determines the approval path. Line amounts are still summed for the routed total, but line departments have no routing effect. Chains are single-step in practice. |
| Rearranging or recoding lines reset approvals | The approval fingerprint is header department + summed total + currency, so only those inputs reset approvals |
| No override tier | **Universal Approver Level** checkbox on the Approval Level record. Anyone named (primary or secondary) on a matrix rule at a flagged level may approve or deny ANY bill, at any amount, in one action. A universal approval settles the whole bill. Self-approval policy still applies to universal approvers. Universal approvers see every pending bill in My Approvals and in the native queue. |
| Bill Total Gate guarded against line-splitting across departments | With header-only routing the gate cannot fire (the routed subtotal IS the bill total). Gate fields are retained but dormant; safe to leave unset. |

## What changed from v4

| v4 behaviour | v5 behaviour |
|---|---|
| Unmatched matrix cell returned `No Approval Needed` → bill auto-approved | The matrix is **opt-in**: a department with no rules needs no approval, and an empty band **inherits the nearest configured band below it**. A cell explicitly marked Required with no approver is still an error and routes to the fallback. |
| Read header `department` | Reads **line** departments, subtotalled per department |
| Read `usertotal` / `total` in `beforeSubmit` (0 for CSV/API/script creates) | Sums line amounts directly — never trusts an uncalculated header total |
| Single approver, Backup vs Co-approver mode setting | Ordered **chain** of steps; each step has a primary and secondary, **either may approve** |
| Native `nextapprover` never set | Set on every advance, so the standard queue and saved searches work |
| `approvalstatus` written via `afterSubmit` `submitFields` | Written on the record in `beforeSubmit` |
| No threshold gate | **Bill Total Gate** step blocks splitting a large bill across departments |
| Payment guard `catch → continue` (fail-open) | Guard blocks when it cannot verify a bill (fail-closed) |
| No logging anywhere | `log.error` / `log.audit` on every failure path and gap |

## Install order

1. `suitecloud project:deploy`
2. **Lists → Custom → RAX Approval Level** — create bands. Sequence must be unique; exactly one band ticked **Unlimited** with the highest sequence. Set the **Total Gate Approver** on the bands that should catch split bills.
3. **RAX Approval Setting** — create one record. Fallback Approver is optional unless Strict Gap Handling is on.
4. Open the **RAX Approval Administration** Suitelet and configure the matrix. You only need a cell where routing *changes* — leave the rest blank.
5. Confirm **Setup → Company → Enable Features → Employees → Approval Routing → Vendor Bills** is *checked* (see below).
6. Undeploy any other approval solution on Vendor Bill.

## Native approval settings

Leave the **Vendor Bills** box under Approval Routing **checked**, and do **not** build a SuiteFlow workflow.

That checkbox means "something other than standard approval owns this record." It makes `approvalstatus` and `nextapprover` writable, which this project requires. It does **not** put bills into Pending Approval — a workflow normally does that, and here the User Event does it instead. That gap is why every bill in the sandbox saved as Approved: the box was checked, nothing set the status, and NetSuite defaulted to `2`.

Unchecking it would restore supervisor-hierarchy approvals, which ignore the matrix entirely and would fight this script.

The field help's warning about clearing Pending Approval bills applies to *enabling* the preference, which has already happened. No action needed.

## Configuration checklist

- Department is **mandatory on the Vendor Bill header**. Line departments are ignored for routing.
- Exactly **one** active RAX Approval Setting record.
- Gate Approver fields on the universal level act as the fallback approver source for the automatic C-Suite step when a department has no C-Suite matrix cell. Fill the C-Suite matrix row instead where possible.
- Fallback Approver only needed for Strict Gap Handling or for lines that somehow have no department.

## How routing works

1. Line amounts are summed into a single total, attributed to the **header department**.
2. That total is banded against the Approval Levels.
3. The matrix cell for (band, department) yields a primary and secondary approver.
   - Department has **no rules at all** → no approval required.
   - Band has **no cell** → inherits the nearest configured band *below* it that names an approver. Inheritance is downward only, so a larger bill can never draw a weaker approver than a smaller one in the same department.
   - Cell says **No Approval Needed** → that department clears.
   - Cell says **Approval Required with no approver** → configuration error; routes to the fallback and logs `log.error`.
4. Steps routing to the same primary are **merged**; the highest band's approver pair wins.
5. Steps are ordered **largest subtotal first**, line order as tiebreak.
6. If the **bill total** bands higher than any department subtotal did, that band's Total Gate Approver is appended as the final step.
7. Step 1 becomes Current. `approvalstatus = 1`, `nextapprover` = step 1's primary.
8. Either the primary or the secondary approves. The chain advances. When the last step approves, `approvalstatus = 2`.
9. Any denial denies the bill and marks remaining steps Skipped.

### Self-approval

When Prevent Self-Approval is on and the preparer is the matrix approver: the secondary takes the step → else escalate to the next band naming someone else → else fallback approver.

## Edit lock

| Bill state | Routing-relevant edit | Result |
|---|---|---|
| Fully approved | yes | **Blocked** unless Approver on this bill or override role; authorised edit rebuilds the chain from zero |
| Fully approved | no (memo, attachment) | allowed, no reset |
| Partially approved | yes | allowed, **all approvals reset**, chain rebuilt |
| Partially approved | no | allowed, chain untouched |

"Routing-relevant" is decided by comparing a stored fingerprint of line departments, line amounts, currency and exchange rate. This covers UI, CSV, RESTlet and scripted edits without maintaining a field list.

An orange banner warns on edit when approvals exist; a red banner warns when the bill is fully approved.

## Known behaviours to watch in the sandbox

- **`record.submitFields` fires user events as XEDIT.** The UE exempts its own execution contexts (`SUITELET`, `USER_EVENT`, `WORKFLOW`) so the engine cannot lock or re-trigger itself. If you add a Map/Reduce that touches bills, add `SCHEDULED`/`MAPREDUCE` to `SELF_CONTEXTS` or it will trip the edit lock.
- **Native approvals are absorbed, not ignored.** If the current step's approver clicks NetSuite's own Approve button, `afterSubmit` records it against the step and advances. Anyone else's native approval is reverted and logged.
- **Custom list internal IDs differ per account.** Nothing compares display text; IDs are resolved at runtime from the list scriptid and memoised per execution. Renaming a list *value* is safe; renaming the *list* is not.
- **`getLineCount` returns `-1`** when a sublist is absent — all loops guard for it.
- **`<name>` not `<n>`** in the object XML. The v4 zip had `<n>` tags, which are not valid SDF and would fail validation.

## Files

```
src/FileCabinet/SuiteScripts/RionAX/
  rax_lib_approval.js        engine: banding, matrix lookup, chain build, steps, decisions, tab HTML
  rax_ue_vb_approval.js      Vendor Bill UE: build, lock, native sync
  rax_ue_vp_guard.js         Bill Payment UE: fail-closed payment block
  rax_ue_matrix_validate.js  Rule/Level UE: uniqueness and consistency
  rax_cs_vb_approval.js      Approve/Deny buttons
  rax_sl_approval_action.js  applies decisions, deny-reason form
  rax_sl_my_approvals.js     approver queue (primary OR secondary)
  rax_sl_approval_admin.js   matrix grid, coverage report, settings
  rax_cs_approval_admin.js   grid serialisation
```

## Test script

1. Bill, one line, dept with a rule below band 1 threshold → `No Approval Needed`, `approvalstatus 2`, no steps.
2. Bill, one line, above threshold → one step, Current, `nextapprover` set, `approvalstatus 1`.
3. Bill, three lines, three departments → three steps ordered by subtotal desc.
4. Two departments sharing an approver → merged into one step.
5. Five lines × $9,000 across five departments under a $10,000 band → gate step appended.
6. Secondary approver approves → step advances; secondary is recorded as Decided By.
7. Deny at step 2 → bill Denied, step 3 Skipped, payment blocked.
8. Edit a line amount at step 2 of 3 → all approvals reset, chain rebuilt, warning banner shown.
9. Edit a fully approved bill as a non-approver → blocked with the lock message.
10. CSV import a bill → chain builds correctly (this is the case `usertotal` broke in v4).
11. Line in a department absent from the matrix → no step, bill approves, `log.audit` written. This is intended behaviour.
12. Department configured at band 1 (Director) but not band 3; bill lands in band 3 → step inherits Director, level shown as `(inherited)`.
13. Same bill, large total, gate approver set on band 3 → Director step **plus** the gate step.
