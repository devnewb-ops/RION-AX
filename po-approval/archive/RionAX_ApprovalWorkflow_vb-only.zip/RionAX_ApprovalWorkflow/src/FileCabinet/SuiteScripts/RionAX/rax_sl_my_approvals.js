/**
 * rax_sl_my_approvals.js  —  RAX v6.0
 *
 * The approver's queue. Lists every bill whose CURRENT step names the logged-in
 * user as primary OR secondary - which is how "either approver may act" reaches
 * people the native nextapprover field cannot hold.
 *
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/search', 'N/runtime', 'N/ui/serverWidget', 'N/url', 'N/ui/message', './rax_lib_approval'],
(search, runtime, serverWidget, url, message, lib) => {

    const onRequest = (context) => {
        if (context.request.method !== 'GET') return;

        const form = serverWidget.createForm({ title: 'My Vendor Bill Approvals' });
        const msg = context.request.parameters.custparam_msg;
        if (msg) {
            form.addPageInitMessage({
                type: /not applied|could not/i.test(msg) ? message.Type.ERROR : message.Type.CONFIRMATION,
                title: 'Approval', message: msg
            });
        }

        const userId = String(runtime.getCurrentUser().id);
        const universal = lib.isUniversalApprover(userId);
        const rows = pending(userId, universal);

        const list = form.addSublist({
            id: 'custpage_queue', type: serverWidget.SublistType.LIST, label: 'Awaiting Your Decision'
        });
        list.addField({ id: 'custpage_bill', type: serverWidget.FieldType.TEXT, label: 'Bill' });
        list.addField({ id: 'custpage_vendor', type: serverWidget.FieldType.TEXT, label: 'Vendor' });
        list.addField({ id: 'custpage_date', type: serverWidget.FieldType.TEXT, label: 'Date' });
        list.addField({ id: 'custpage_dept', type: serverWidget.FieldType.TEXT, label: 'Your Step Covers' });
        list.addField({ id: 'custpage_amount', type: serverWidget.FieldType.TEXT, label: 'Step Amount' });
        list.addField({ id: 'custpage_total', type: serverWidget.FieldType.TEXT, label: 'Bill Total' });
        list.addField({ id: 'custpage_step', type: serverWidget.FieldType.TEXT, label: 'Step' });
        list.addField({ id: 'custpage_role', type: serverWidget.FieldType.TEXT, label: 'You Are' });
        list.addField({ id: 'custpage_act', type: serverWidget.FieldType.TEXT, label: 'Action' });

        rows.forEach((r, i) => {
            const set = (id, v) => {
                if (v === null || v === undefined || v === '') return;
                list.setSublistValue({ id: id, line: i, value: String(v) });
            };
            set('custpage_bill', link('/app/accounting/transactions/vendbill.nl?id=' + r.billId,
                r.tranid || ('Bill ' + r.billId)));
            set('custpage_vendor', lib.esc(r.vendor));
            set('custpage_date', r.trandate);
            set('custpage_dept', lib.esc(r.label));
            set('custpage_amount', lib.money(r.amount));
            set('custpage_total', lib.money(r.total));
            set('custpage_step', r.seq + ' of ' + r.count);
            set('custpage_role', r.role);
            set('custpage_act',
                link(actionUrl(r.billId, 'approve'), 'Approve') + ' &nbsp;|&nbsp; ' +
                link(actionUrl(r.billId, 'deny'), 'Deny'));
        });

        if (!rows.length) {
            form.addField({ id: 'custpage_none', type: serverWidget.FieldType.INLINEHTML, label: ' ' })
                .defaultValue = '<div style="padding:14px;font:13px Arial;color:#666">' +
                    'Nothing is waiting on you right now.</div>';
        }

        context.response.writePage(form);
    };

    const actionUrl = (billId, action) => url.resolveScript({
        scriptId: 'customscript_rax_sl_approval_action',
        deploymentId: 'customdeploy_rax_sl_approval_action',
        params: { billid: billId, action: action, src: 'list' }
    });

    const link = (href, text) => '<a href="' + href + '">' + text + '</a>';

    const pending = (userId, universal) => {
        const out = [];
        // Universal approvers (flagged Approval Level) see every bill awaiting
        // a decision, not only steps that name them.
        const filters = [[lib.STEP.status, 'is', lib.STEP_STATUS.CURRENT]];
        if (!universal) {
            filters.push('AND', [
                [lib.STEP.primary, 'anyof', userId], 'OR',
                [lib.STEP.secondary, 'anyof', userId]
            ]);
        }
        search.create({
            type: lib.REC.STEP,
            filters: filters,
            columns: [
                lib.STEP.bill, lib.STEP.seq, lib.STEP.label, lib.STEP.amount,
                lib.STEP.primary, lib.STEP.secondary,
                search.createColumn({ name: 'trandate', join: lib.STEP.bill }),
                search.createColumn({ name: 'tranid', join: lib.STEP.bill }),
                search.createColumn({ name: 'entity', join: lib.STEP.bill }),
                search.createColumn({ name: lib.BILL.stepCount, join: lib.STEP.bill }),
                search.createColumn({ name: lib.STEP.seq, sort: search.Sort.ASC })
            ]
        }).run().each((r) => {
            const billId = String(r.getValue(lib.STEP.bill));
            out.push({
                billId: billId,
                tranid: String(r.getValue({ name: 'tranid', join: lib.STEP.bill }) || ''),
                vendor: String(r.getText({ name: 'entity', join: lib.STEP.bill }) || ''),
                trandate: String(r.getValue({ name: 'trandate', join: lib.STEP.bill }) || ''),
                label: String(r.getValue(lib.STEP.label) || ''),
                amount: parseFloat(r.getValue(lib.STEP.amount)) || 0,
                total: 0,
                seq: parseInt(r.getValue(lib.STEP.seq), 10) || 0,
                count: parseInt(r.getValue({ name: lib.BILL.stepCount, join: lib.STEP.bill }), 10) || 0,
                role: String(r.getValue(lib.STEP.primary)) === String(userId) ? 'Primary'
                    : (String(r.getValue(lib.STEP.secondary)) === String(userId) ? 'Secondary' : 'Universal')
            });
            return true;
        });

        // Bill totals in one pass rather than per row.
        if (out.length) {
            const ids = out.map((o) => o.billId);
            const totals = {};
            search.create({
                type: search.Type.VENDOR_BILL,
                filters: [['internalid', 'anyof', ids], 'AND', ['mainline', 'is', 'T']],
                columns: ['total']
            }).run().each((r) => {
                totals[String(r.id)] = Math.abs(parseFloat(r.getValue('total')) || 0);
                return true;
            });
            out.forEach((o) => { o.total = totals[o.billId] || 0; });
        }

        return out;
    };

    return { onRequest };
});
