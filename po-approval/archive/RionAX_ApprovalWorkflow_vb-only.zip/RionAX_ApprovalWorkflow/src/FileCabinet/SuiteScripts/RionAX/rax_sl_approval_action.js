/**
 * rax_sl_approval_action.js  —  RAX v6.0
 *
 * Applies a decision against the CURRENT step of a bill's approval chain.
 * Reached from the record buttons or the My Approvals list.
 *
 * Approve is applied on GET. Deny renders a short form first so the reason is
 * captured, then applies on POST. Authorisation is re-validated server-side in
 * the library on every call, against freshly read state - the buttons are
 * convenience, not security.
 *
 * Params: billid, action (approve|deny), src (record|list)
 *
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/redirect', 'N/record', 'N/ui/serverWidget', './rax_lib_approval'],
(redirect, record, serverWidget, lib) => {

    const onRequest = (context) => {
        const req = context.request;
        const p = req.parameters;
        const action = p.action === 'approve' ? 'approve' : 'deny';
        const src = p.src === 'list' ? 'list' : 'record';
        const billId = p.billid;

        if (!billId) return finish(context, src, null, 'Missing transaction reference.');

        if (req.method === 'GET' && action === 'deny') {
            context.response.writePage(denyForm(billId, src));
            return;
        }

        const comment = (req.method === 'POST' ? req.parameters.custpage_reason : '') || '';

        let result;
        try {
            result = lib.applyStepDecision(billId, action, comment);
        } catch (e) {
            log.error({ title: 'RAX applyStepDecision failed',
                details: 'bill=' + billId + ' action=' + action + ' :: ' + e.message });
            result = { ok: false, reason: 'The decision could not be applied: ' + e.message };
        }

        finish(context, src, billId, result.ok ? result.reason : 'Not applied: ' + result.reason);
    };

    const denyForm = (billId, src) => {
        const form = serverWidget.createForm({ title: 'Deny Vendor Bill' });
        form.addField({ id: 'custpage_billid', type: serverWidget.FieldType.TEXT, label: 'Bill' })
            .updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
            .defaultValue = String(billId);
        form.addField({ id: 'custpage_action', type: serverWidget.FieldType.TEXT, label: 'Action' })
            .updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
            .defaultValue = 'deny';
        form.addField({ id: 'custpage_src', type: serverWidget.FieldType.TEXT, label: 'Source' })
            .updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
            .defaultValue = src;

        const reason = form.addField({
            id: 'custpage_reason', type: serverWidget.FieldType.TEXTAREA, label: 'Reason for Denial'
        });
        reason.isMandatory = true;
        reason.setHelpText({
            help: 'This is recorded on the approval step and shown on the bill. Denying clears the ' +
                  'remaining steps; the preparer must correct and resubmit the bill.'
        });

        form.addSubmitButton({ label: 'Deny Bill' });
        form.addButton({ id: 'custpage_cancel', label: 'Cancel', functionName: 'history.back' });
        return form;
    };

    const finish = (context, src, billId, msg) => {
        if (src === 'list' || !billId) {
            redirect.toSuitelet({
                scriptId: 'customscript_rax_sl_my_approvals',
                deploymentId: 'customdeploy_rax_sl_my_approvals',
                parameters: { custparam_msg: msg }
            });
            return;
        }
        redirect.toRecord({ type: record.Type.VENDOR_BILL, id: billId });
    };

    return { onRequest };
});
